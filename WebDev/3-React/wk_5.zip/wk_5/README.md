Updated React nucampsite repo with hooks, function components, and RTK

Instructors:

Use:

### `npm ci`

to clean install the node_modules folder in any branch. Clean install means it will use the existing package-lock.json file and won't alter it.

Use:

### `git branch`

to view the available branches. Each branch represents the nucampsite course project at the end of a particular exercise or workshop task.

Use:

### `git switch <branchname>`

To checkout and switch to a branch. You can use the files in that branch as an answer key, to compare against your students' for grading and to provide help. P

Please do not share this repository with any students. It is for instructors' use only.

If you find any issues with this repository, contact Nucamp's Director of Curriculum.
